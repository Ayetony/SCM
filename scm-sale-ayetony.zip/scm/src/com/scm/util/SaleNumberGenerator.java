package com.scm.util;

import java.util.UUID;

public class SaleNumberGenerator {
	/**
	 * @author  Ayetony Miao
	 * UUID生成订单号
	 * @code 处理后的String类型的编码
	 */
	public static String generate(){
		
		
		long productCode = UUID.randomUUID().getLeastSignificantBits();
		String code=String.valueOf(productCode);
		code=code.substring(1);
		System.out.println("product code generated"+code);
		return  String.valueOf(code);
		
	}


}
