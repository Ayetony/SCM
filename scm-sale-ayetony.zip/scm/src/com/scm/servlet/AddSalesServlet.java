package com.scm.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scm.dao.TransactionProcess;
import com.scm.model.Product;
import com.scm.model.Soitem;
import com.scm.model.Somain;

public class AddSalesServlet extends HttpServlet {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Somain  main=new Somain();
		String prePayFee="0";
	    String saleNumber=request.getParameter("saleNumber");
		String payType=request.getParameter("payType");
		String tipFee=request.getParameter("tipFee");
		String account=request.getParameter("account");
		String customerCode=request.getParameter("customer");
		String createTime=request.getParameter("createTime");
		String soTotal=request.getParameter("saleTotal");
		if(payType.equals("1"))
		prePayFee=request.getParameter("prePayFee");
		main.setAccount(account);
		main.setCreateTime(createTime);
		main.setCustomerCode(customerCode);
		main.setPayType(payType);
		main.setPrePayFee(Float.parseFloat(prePayFee));
		main.setSoTotal(Float.parseFloat(soTotal));
		main.setSoId(saleNumber);
		main.setTipFee(Float.parseFloat(tipFee));
		main.setProductTotal(Float.parseFloat(soTotal) - Float.parseFloat(tipFee));
		
		//明细
		String [] productQty=request.getParameterValues("spsl");
		String [] productCode=request.getParameterValues("spbm");
		String [] productUnitName=request.getParameterValues("spdw");
		String [] productUnitPrice=request.getParameterValues("spdj");
		String [] productItemPrice=request.getParameterValues("spzj");
		List<Soitem> saleItems=new ArrayList<Soitem>();
		List<Product> products=new ArrayList<Product>();
		Soitem item=null;
		Product product=null;
		for(int i=0;i<productQty.length;i++){
			item=new Soitem();
			item.setSoId(saleNumber);
			item.setItemPrice(Float.parseFloat(productItemPrice[i]));
			item.setProductCode(productCode[i]);
			item.setNum(Integer.parseInt(productQty[i]));
			item.setUnitName(productUnitName[i]);
			item.setUnitPrice(Float.parseFloat(productUnitPrice[i]));
			saleItems.add(item);
			//prepare product.
			product=new Product();
			product.setProductCode(productCode[i]);
			product.setSoNum(Integer.parseInt(productQty[i]));
			products.add(product);
			System.out.println(item.getItemPrice()+" "+item.getSoId()+" "+item.getNum()+" "+item.getProductCode());
			
		}
		
		System.out.println(new TransactionProcess().addSaleItemAndUpdateProduct(main, saleItems, products));
		request.getRequestDispatcher("/ProductServlet").forward(request, response);
		
		
		
		
		
	}

}
