package com.scm.servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.scm.dao.CustomerDao;
import com.scm.dao.ProductDao;
import com.scm.dao.SomainDao;
import com.scm.model.Product;
import com.scm.util.SaleNumberGenerator;

public class ProductServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		List<Product> list = new ProductDao().getAllProducts();
		session.setAttribute("products", list);
		System.out.println(request.getContextPath());
		session.setAttribute("username", "scm123");
		// generate sale's order code.销售单编号用UUID生成
		session.setAttribute("sale_number", SaleNumberGenerator.generate());
		session.setAttribute("map", new CustomerDao().getAllCustomers());
		session.setAttribute("newsales",new SomainDao().getAllNewSales("scm123"));
		response.sendRedirect(request.getContextPath() + "/listAddedSales.jsp");
		

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
