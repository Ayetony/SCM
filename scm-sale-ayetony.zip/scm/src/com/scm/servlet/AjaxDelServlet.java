package com.scm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.scm.dao.TransactionProcess;
import com.scm.model.Somain;

/*
 * @author  ayetony miao
 * 
 * 对销售单进行删除时进行ajax处理的servlet处理
 */

public class AjaxDelServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html,charset=utf-8");
		PrintWriter out = response.getWriter();
		String soId = request.getParameter("soId");
		int flag = new TransactionProcess().deleteSaleItemAndMain(soId);
		System.out.println("ajax:" + flag);
		HttpSession session=request.getSession();
		if (flag == 1) {
			out.write(URLEncoder.encode("删除成功", "utf-8"));
		    List<Somain> somains=new ArrayList<Somain>();
		    somains=(List<Somain>)session.getAttribute("newsales");
		    for(Somain somain : somains){
		    	 if(somain.getSoId().equals(soId)){
		    		 somains.remove(somain);
		    		 session.setAttribute("newsales",somains);
		    		 break;
		    	 }   
		    }
		   
		} else {
			out.write(0);
		}
		System.out.println(soId);
		out.flush();
		out.close();
		/*if(flag==1){
			//对于删除成功是否重新对数据库进行存储,个人意见是只是更新session ,不去数据库重新拿，因为删除的数据是一对一的。
			request.getRequestDispatcher("/ProductServlet").forward(request, response);
		}*/
		
	}

}
