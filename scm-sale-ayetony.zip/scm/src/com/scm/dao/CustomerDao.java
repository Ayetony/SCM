package com.scm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.scm.DBconn.DBConnection;
import com.scm.model.Customer;

/*
 +--------------+--------------+------+-----+---------+-------+
 | Field        | Type         | Null | Key | Default | Extra |
 +--------------+--------------+------+-----+---------+-------+
 | CustomerCode | varchar(20)  | NO   | PRI | NULL    |       |
 | Name         | varchar(100) | NO   |     | NULL    |       |
 | Password     | varchar(20)  | NO   |     | NULL    |       |
 | Contactor    | char(10)     | NO   |     | NULL    |       |
 | Address      | varchar(100) | NO   |     | NULL    |       |
 | Postcode     | char(8)      | YES  |     | NULL    |       |
 | Tel          | char(20)     | NO   |     | NULL    |       |
 | Fax          | char(20)     | YES  |     | NULL    |       |
 | CreateDate   | char(20)     | NO   |     | NULL    |       |
 +--------------+--------------+------+-----+---------+-------+
 */

/*
 * 
 * 客户管理
 * @author ayetony miao 920101938@qq.com
 * 所实现的方法有：增加用户， 查找所有用户  删除用户   查找用户
 */

public class CustomerDao {
   //create
	public boolean createCustomer(Customer customer) {

		PreparedStatement ps = null;
		String sql = "insert into customer values(?,?,?,?,?,?,?,?,now())";
		Connection conn = null;
		

		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			conn.setAutoCommit(false);
			ps.setString(1, customer.getCustomerCode());
			ps.setString(2, customer.getName());
			ps.setString(3, customer.getPassWord());
			ps.setString(4, customer.getContactor());
			ps.setString(5, customer.getAddress());
			ps.setString(6, customer.getPostCode());
			ps.setString(7, customer.getTel());
			ps.setString(8, customer.getFax());
			int flag=ps.executeUpdate();
			if(flag == 1){
				conn.commit();
				conn.setAutoCommit(true);
				System.out.println("customer:"+sql);
			    return true;
			}
			
		} catch (SQLException e) {
			
			
			try {
				conn.rollback();
				conn.setAutoCommit(true);
				System.out.println("rollbacking.customer create failed.");
				return false;
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return false;
	

	}
	
//select   只需要获取customerCode 和 name两项。
	public HashMap<String ,String> getAllCustomers(){
		ResultSet rs=null;
		HashMap<String ,String> map=null;
		PreparedStatement ps=null;
		String sql="select CustomerCode ,Name from customer";
		Connection conn=null;
		try {
			conn=DBConnection.getConn();
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			map=new HashMap<String ,String>();
			System.out.println("getAllCustomer's code and name:"+sql);
			while(rs.next()){
				map.put(rs.getString("CustomerCode"),rs.getString("Name"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			
		     DBConnection.close(rs, ps, conn);
			
		}
		
         return map;		
	}
	
	

	
	
	public static void main(String[] args) {
//		Customer customer = new Customer();
//		customer.setAddress("live in NY city.");
//		customer.setContactor("Bolk");
//		customer.setFax("456789");
//		customer.setName("tony mols");
//		customer.setPassWord("tony");
//		customer.setPostCode("AZ001");
//		customer.setTel("158999001122");
//		customer.setCustomerCode("cust90001");
//		new CustomerDao().createCustomer(customer);
		   HashMap<String,String> map=new CustomerDao().getAllCustomers();
		   for(String key : map.keySet()){
			   System.out.println(key);
		   }
				   
	}
	

}
