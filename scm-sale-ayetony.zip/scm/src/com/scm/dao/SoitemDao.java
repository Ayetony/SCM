package com.scm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scm.DBconn.DBConnection;
import com.scm.model.Soitem;
import com.scm.model.Somain;


/**
 * @author Ayetony Miao
 * @addBatchSoitem addBatch to insert the soitem table .
 */

public class SoitemDao {

	public boolean addItemsAndMain(List<Soitem> soitem, Somain somain) {

		if (soitem == null || somain == null) {
			return false;
		}
		PreparedStatement ps = null;
		String sql = "insert into Soitem values(?,?,?,?,?,?)";
		Connection conn = null;
		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			conn.setAutoCommit(false);
			for (Soitem item : soitem) {
				ps.setString(1, item.getSoId());
				ps.setString(2, item.getProductCode());
				ps.setFloat(3, item.getUnitPrice());
				ps.setInt(4, item.getNum());
				ps.setString(5, item.getUnitName());
				ps.setFloat(6, item.getItemPrice());
				ps.addBatch();
			}
			int[] a = ps.executeBatch();
			// next sql insert.
			String sqlOne = "insert into Somain(SOID,CustomerCode,Account,CreateTime,TipFee,ProductTotal,SOTotal,PayType,PrePayFee,Status) values(?,?,?,?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sqlOne);
			ps.setString(1, somain.getSoId());
			ps.setString(2, somain.getCustomerCode());
			ps.setString(3, somain.getAccount());
			ps.setString(4, somain.getCreateTime());
			ps.setFloat(5, somain.getTipFee());
			ps.setFloat(6, somain.getProductTotal());
			ps.setFloat(7, somain.getSoTotal());
			ps.setString(8, somain.getPayType());
			ps.setFloat(9, somain.getPrePayFee());
			ps.setInt(10, 0);
			int flag = ps.executeUpdate();

			for (int x : a) {
				if (x == 0 || flag != 1) {
					conn.rollback();
					conn.setAutoCommit(true);
					System.out
							.println("rollbacking.sales items and main. add failed.");
					return false;
				}
			}
			conn.commit();
			conn.setAutoCommit(true);
			return true;
		} catch (SQLException e) {
			try {
				conn.rollback();
				conn.setAutoCommit(true);
				System.out
						.println("rollbacking.sales items and main. add failed.");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			DBConnection.close(null, ps, conn);
		}
		return false;
	}

	public boolean addBatchSaleitem(Connection conn, PreparedStatement ps,
			List<Soitem> soitem) {

		if (soitem == null) {
			return false;
		}
		String sql = "insert into Soitem values(?,?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			for (Soitem item : soitem) {
				ps.setString(1, item.getSoId());
				ps.setString(2, item.getProductCode());
				ps.setFloat(3, item.getUnitPrice());
				ps.setInt(4, item.getNum());
				ps.setString(5, item.getUnitName());
				ps.setFloat(6, item.getItemPrice());
				int flag = ps.executeUpdate();
				if (flag != 1) {
					return false;
				}
			}
			System.out
					.println("successfully execute addBatchSaleitem from SoitemDao:"
							+ sql);
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}
    //删除对应主菜单的明细
	public boolean deleteItem(Connection conn, PreparedStatement ps,
			 String soId) {
	
		String sql = "delete from soitem where soid=?";
		
		try {
			ps = conn.prepareStatement(sql);
            ps.setString(1, soId);
			int flag = ps.executeUpdate();
			if(flag>=1)
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}
	/*
	 * 
	 * soitem table desc
	 SOID        | varchar(20) | NO   | PRI | NULL    |       |
	 | ProductCode | char(20)    | NO   | PRI | NULL    |       |
	 | UnitPrice   | float       | NO   |     | NULL    |       |
	 | Num         | int(11)     | NO   |     | NULL    |       |
	 | UnitName    | char(5)     | NO   |     | NULL    |       |
	 | ItemPrice   | float       | NO   |     | NULL    |       |

	 */
	//根据soid查询子单
	public List<Soitem> getItemsById(String soId){
		
		ResultSet rs = null;
		List<Soitem> list = null;
		PreparedStatement ps = null;
		String sql = "select productcode ,unitprice,num,unitname,itemprice from soitem where soid=?";
		Connection conn = null;
		Soitem soitem = null;
		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			ps.setString(1, soId);
			rs = ps.executeQuery();
			list = new ArrayList<Soitem>();
			System.out.println("select  sql:"+sql);
			while (rs.next()) {
		         soitem=new Soitem();
				 soitem.setItemPrice(rs.getFloat("itemprice"));
				 soitem.setNum(rs.getInt("num"));
				 soitem.setProductCode(rs.getString("productcode"));
				 soitem.setUnitName(rs.getString("unitname"));
				 soitem.setUnitPrice(rs.getFloat("unitprice"));
				 list.add(soitem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return list;
	}
	
	public static void main(String[] args) {
		new SoitemDao().getItemsById("6557240398141229714");
	}
	

}
