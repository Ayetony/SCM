package com.scm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scm.DBconn.DBConnection;
import com.scm.model.Somain;

/*
 * 
 * SOID         | varchar(20)  | NO   | PRI | NULL    |       |
 | CustomerCode | varchar(20)  | YES  | MUL | NULL    |       |
 | Account      | varchar(20)  | YES  | MUL | NULL    |       |
 | CreateTime   | char(20)     | NO   |     | NULL    |       |
 | TipFee       | float        | NO   |     | NULL    |       |
 | ProductTotal | float        | NO   |     | NULL    |       |
 | SOTotal      | float        | NO   |     | NULL    |       |
 | PayType      | char(12)     | NO   |     | NULL    |       |
 | PrePayFee    | float        | NO   |     | NULL    |       |
 | Status       | int(11)      | NO   |     | NULL    |       |
 | Remark       | varchar(255) | YES  |     | NULL    |       |
 | StockTime    | char(20)     | YES  |     | NULL    |       |
 | StockUser    | char(20)     | YES  |     | NULL    |       |
 | PayTime      | char(20)     | YES  |     | NULL    |       |
 | PayUser      | char(20)     | YES  |     | NULL    |       |
 | PrePayTime   | char(20)     | YES  |     | NULL    |       |
 | PrePayUser   | char(20)     | YES  |     | NULL    |       |
 | EndTime      | char(20)     | YES  |     | NULL    |       |
 | EndUser      | char(20)     | YES  |     | NULL    |       |
 +--------------+----------
 */
/*
 * 
 * @author ayetony miao 
 * 
 * 
 */

public class SomainDao {
	// transaction addMainSale
	public boolean addMainSale(Connection conn, PreparedStatement ps,
			Somain somain) {
		// private String soId;//销售单编号
		// private String customerCode;//客户编号
		// private String account;//用户账号
		// private String createTime;//创建时间
		// private float tipFee;//附加费用
		// private float productTotal;//产品总价
		// private float soTotal;//产品总价
		// private String payType;//付款方式
		// private float prePayFee;//最低预付金额
		// private int status;//处理状态

		if (somain == null) {
			return false;
		}
		String sql = "insert into Somain(SOID,CustomerCode,Account,CreateTime,TipFee,ProductTotal,SOTotal,PayType,PrePayFee,Status) values(?,?,?,?,?,?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, somain.getSoId());
			ps.setString(2, somain.getCustomerCode());
			ps.setString(3, somain.getAccount());
			ps.setString(4, somain.getCreateTime());
			ps.setFloat(5, somain.getTipFee());
			ps.setFloat(6, somain.getProductTotal());
			ps.setFloat(7, somain.getSoTotal());
			ps.setString(8, somain.getPayType());
			ps.setFloat(9, somain.getPrePayFee());
			ps.setInt(10, 0);
			int flag = ps.executeUpdate();
			if (flag == 1) {
				System.out
						.println("sucessfully execute addMainSale from SomainDao:"
								+ sql);
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	// fetch all of the new sales .
	public List<Somain> getAllNewSales(String account) {

		ResultSet rs = null;
		List<Somain> list = null;
		PreparedStatement ps = null;
		String sql = "select soid ,createtime,sototal,status from somain where account=?";
		Connection conn = null;
		Somain somain = null;

		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			ps.setString(1, account);
			rs = ps.executeQuery();
			list = new ArrayList<Somain>();
			while (rs.next()) {
				somain = new Somain();
				somain.setSoId(rs.getString("soid"));
				somain.setCreateTime(rs.getString("createtime"));
				somain.setSoTotal(rs.getFloat("sototal"));
				somain.setStatus(rs.getInt("status"));
				list.add(somain);

			}

			for (Somain so : list) {

				System.out.println(so.getSoId());
				System.out.println(so.getCreateTime());
				System.out.println(so.getSoTotal());

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}

		return list;

	}

	// 删除主销售单子
	public boolean deleteItem(Connection conn, PreparedStatement ps, String soId) {
		String sql = "delete from somain where soid=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, soId);
			int flag = ps.executeUpdate();
			if (flag != 1) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}


	
	// 根据ID缠着一个somain对象数据
	public Somain getSomainById(String soId) {

		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = "select CustomerCode,Account,CreateTime,TipFee,ProductTotal,SOTotal,PayType,PrePayFee from Somain where SOId=?";
		Connection conn = null;
		Somain somain = null;

		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			ps.setString(1, soId);
			rs = ps.executeQuery();
			System.out.println("sql:"+sql);
			while (rs.next()){
				
				somain = new Somain();
				somain.setSoId(soId);
				somain.setCreateTime(rs.getString("CreateTime"));
				somain.setSoTotal(rs.getFloat("SOTotal"));
				somain.setCustomerCode(rs.getString("customerCode"));
				somain.setAccount(rs.getString("account"));
				somain.setTipFee(rs.getFloat("TipFee"));
				somain.setSoTotal(rs.getFloat("SOTotal"));
				somain.setPayType(rs.getString("payType"));
				somain.setPrePayFee(rs.getFloat("PrePayFee"));
                break;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}

		return somain;

	}

	public static void main(String[] args) {
		new SomainDao().getAllNewSales("scm123");
		new SomainDao().getSomainById("6557240398141229714");
		
	}

}
