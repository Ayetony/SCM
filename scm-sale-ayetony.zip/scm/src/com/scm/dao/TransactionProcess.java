package com.scm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.scm.DBconn.DBConnection;
import com.scm.model.Product;
import com.scm.model.Soitem;
import com.scm.model.Somain;

/*
 * 
 * 新增销售单的事务处理
 * 
 * @author ayetony miao .
 * @addSaleItenAndUpdateProduct  增加主单和子单与更新产品销售的待发的事务DDL处理
 * 
 */

public class TransactionProcess {
	public int addSaleItemAndUpdateProduct(Somain somain, List<Soitem> items,
			List<Product> products) {
		Connection conn = DBConnection.getConn();
		PreparedStatement ps = null;
		// main table and item table addition transaction.
		try {
			conn.setAutoCommit(false);
			System.out
					.println("start transaction for table soitem|somain|product.。。。。。。。。。。。。。");
			if (new SomainDao().addMainSale(conn, ps, somain)
					&& new SoitemDao().addBatchSaleitem(conn, ps, items)
					&& new ProductDao().updateProduct(conn, ps, products)) {
				conn.commit();
				conn.setAutoCommit(true);
				System.out
						.println(" successfull finish transaction for table soitem|somain|product.。。。。。。。。。。。。。");
				return 1;
			} else {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the transaction.");
				return -1;
			}
		} catch (SQLException e) {
			try {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the transaction.");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return -1;

		} finally {
			DBConnection.close(null, ps, conn);
		}
	}

	// 删除主销售单顺带,删除子弹。
	public int deleteSaleItemAndMain(String soId) {
		Connection conn = DBConnection.getConn();
		PreparedStatement ps = null;
		// main table and item table addition transaction.
		try {
			conn.setAutoCommit(false);
			System.out
					.println("-----------------------------------------------------------------------------------------");
			System.out
					.println("start transaction for table soitem|somain|product.。。。。。。。。。。。。。");
			if (new ProductDao().updateProductNum(conn, ps, soId)
					&& new SoitemDao().deleteItem(conn, ps, soId)
					&& new SomainDao().deleteItem(conn, ps, soId)) {
				conn.commit();
				conn.setAutoCommit(true);
				System.out
						.println(" successfull finish transaction for table soitem|somain|product.。。。。。。。。。。。。。");
				return 1;
			} else {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the transaction.");
				return -1;
			}
		} catch (SQLException e) {
			try {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the transaction.");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			DBConnection.close(null, ps, conn);
			System.out
					.println("-----------------------------------------------------------------------------------------");
		}
		return -1;
	}

	// 更新主明细单先删后添加
	
	public int updateSomainAndSoitem(String soId, Somain somain,
			List<Soitem> items, List<Product> products) {
		Connection conn = DBConnection.getConn();
		PreparedStatement ps = null;
		try {
			conn.setAutoCommit(false);
			System.out
					.println("-----------------------------------------------------------------------------------------");
			System.out
					.println("start transaction for table soitem|somain|product.。。。。。。。。。。。。。");
			if (new ProductDao().updateProductNum(conn, ps, soId)
					&& new SoitemDao().deleteItem(conn, ps, soId)
					&& new SomainDao().deleteItem(conn, ps, soId)
					&& new SomainDao().addMainSale(conn, ps, somain)
					&& new SoitemDao().addBatchSaleitem(conn, ps, items)
					&& new ProductDao().updateProduct(conn, ps, products)) {
				conn.commit();
				conn.setAutoCommit(true);
				System.out.println(" successfull finish transaction updateSomainAndSoitem for table soitem|somain|product.。。。。。。。。。。。。。");
				return 1;
			} else {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the updateSomainAndSoitem transaction.");
				return -1;
			}
		} catch (SQLException e) {
			try {
				conn.rollback();
				System.out
						.println("Add-update roll backing.failed to execute the updateSomainAndSoitem transaction.");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			DBConnection.close(null, ps, conn);
			System.out
					.println("-----------------------------------------------------------------------------------------");
		}
		return -1;

	}

}
