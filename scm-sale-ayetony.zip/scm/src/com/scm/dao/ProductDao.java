package com.scm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scm.DBconn.DBConnection;
import com.scm.model.Product;

/*
 * 
 * @author Ayetony miao.
 * @getAllProducts 获取所有的产品信息。
 * 
 */

public class ProductDao {

	// select
	public List<Product> getAllProducts() {

		ResultSet rs = null;
		List<Product> list = null;
		PreparedStatement ps = null;
		String sql = "select * from Product";
		Connection conn = null;
		Product product = null;

		try {
			conn = DBConnection.getConn();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<Product>();
			while (rs.next()) {

				product = new Product();
				product.setCategoryId(rs.getInt("CategoryId"));
				product.setName(rs.getString("Name"));
				product.setUnitName(rs.getString("UnitName"));
				product.setPrice(rs.getFloat("price"));
				product.setProductCode(rs.getString("ProductCode"));
				list.add(product);
			}

		} catch (SQLException e) {
			try {
				conn.rollback();
				conn.setAutoCommit(true);
				System.out.println("rollbacking.sale main. add failed.");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {

			DBConnection.close(rs, ps, conn);

		}

		return list;
	}

	// update product's sonum .
	// update product,(select productcode,num from soitem where
	// soid="7289009639610888555" ) as a set product.sonum=product.sonum - a.num
	// where a.productcode=product.productcode
	public boolean updateProductNum(Connection conn, PreparedStatement ps,String soId) {
		String sql = "update product,(select productcode,num from soitem where soid=?) as a set product.sonum=product.sonum-a.num where a.productcode=product.productcode";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, soId);
			int flag=ps.executeUpdate();
			System.out.println("update product sonum:"+flag);
			System.out.println("sucessfully execute updateProductNum from ProductDao:"+ sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	public boolean updateProduct(Connection conn, PreparedStatement ps,
			List<Product> products) {
		String sql = "update product set sonum=sonum+? where productcode=?";
		try {
			for (Product product : products) {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, product.getSoNum());
				ps.setString(2, product.getProductCode());
				int flag = ps.executeUpdate();
				if (flag != 1) {
					return false;
				}
			}
			System.out
					.println("sucessfully execute updateProduct from ProductDao :"
							+ sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	public static void main(String[] args) {

		System.out.println(new ProductDao().getAllProducts());
	}

}
