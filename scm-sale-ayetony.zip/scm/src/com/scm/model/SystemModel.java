package com.scm.model;

/**
 *	模块�?
 */
public class SystemModel {
	
	private String modelCode;//模块编号
	private String modelName;//模块名称
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public SystemModel(String modelCode, String modelName) {
		super();
		this.modelCode = modelCode;
		this.modelName = modelName;
	}
	public SystemModel() {
		super();
	}
	
	
}
