package com.scm.model;

/**
 *	 采购单明细表模型
 */
public class Poitem {
	
	private String poId;//采购单编号
	private String productCode;//产品编号
	private float unitPrice;//产品单价
	private int num;//产品数量
	private String unitName;//数量单位
	private float itemPrice;//明细总价
	public String getPoId() {
		return poId;
	}
	public void setPoId(String poId) {
		this.poId = poId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public float getItemPrice() {
		return itemPrice;
	}
	public void setItenPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}
	public Poitem(String poId, String productCode, float unitPrice, int num,
			String unitName, float itemPrice) {
		super();
		this.poId = poId;
		this.productCode = productCode;
		this.unitPrice = unitPrice;
		this.num = num;
		this.unitName = unitName;
		this.itemPrice = itemPrice;
	}
	public Poitem() {
		super();
	}
	
	
}
