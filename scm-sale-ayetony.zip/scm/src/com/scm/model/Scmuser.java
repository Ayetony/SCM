package com.scm.model;

/**
 *	用户表 
 */
public class Scmuser {
	private String account;//用户账号
	private String passWord;//密码
	private String name;//姓名
	private String createDate;//添加日期
	private String status;//锁定状态
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Scmuser(String account, String passWord, String name,
			String createDate, String status) {
		super();
		this.account = account;
		this.passWord = passWord;
		this.name = name;
		this.createDate = createDate;
		this.status = status;
	}
	public Scmuser() {
		super();
	}
	
	
}
