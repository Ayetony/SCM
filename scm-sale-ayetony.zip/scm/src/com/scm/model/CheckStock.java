package com.scm.model;

/**
 *	盘点表模型 
 */
public class CheckStock {
	private int stockId; //序列号
	private String productCode;//产品编号
	private int originNum;//原始数量
	private int realNum;//实际数量
	private String stockTime;//盘点时间
	private String createUser;//经手人
	private String description;//损益原因
	private String type;//损益类型
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public int getOriginNum() {
		return originNum;
	}
	public void setOriginNum(int originNum) {
		this.originNum = originNum;
	}
	public int getRealNum() {
		return realNum;
	}
	public void setRealNum(int realNum) {
		this.realNum = realNum;
	}
	public String getStockTime() {
		return stockTime;
	}
	public void setStockTime(String stockTime) {
		this.stockTime = stockTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public CheckStock(int stockId, String productCode, int originNum,
			int realNum, String stockTime, String createUser,
			String description, String type) {
		super();
		this.stockId = stockId;
		this.productCode = productCode;
		this.originNum = originNum;
		this.realNum = realNum;
		this.stockTime = stockTime;
		this.createUser = createUser;
		this.description = description;
		this.type = type;
	}
	public CheckStock() {
		super();
	}
	
	
}
