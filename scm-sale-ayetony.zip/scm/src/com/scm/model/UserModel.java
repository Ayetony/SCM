package com.scm.model;

/**
 *	用户模块表 
 */
public class UserModel {
	private String account;//用户账号
	private String modelCode;//模块编号
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public UserModel(String account, String modelCode) {
		super();
		this.account = account;
		this.modelCode = modelCode;
	}
	public UserModel() {
		super();
	}
	
	
}
