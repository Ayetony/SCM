package com.scm.model;

/**
 *	库存表 
 */
public class Stock {
	private String productCode;//产品编号
	private String name;//名称
	private String unitName;//数量单位
	private int num;//库存数
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public Stock(String productCode, String name, String unitName, int num) {
		super();
		this.productCode = productCode;
		this.name = name;
		this.unitName = unitName;
		this.num = num;
	}
	public Stock() {
		super();
	}
	
}
