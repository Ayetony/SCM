package com.scm.model;
/**
 *	产品分类表模型 
 */
public class Category {
	private int categoryId;//类别序列号
	private String name;//名称
	private String remark;//描述
	
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Category(int categoryId, String name, String remark) {
		super();
		this.categoryId = categoryId;
		this.name = name;
		this.remark = remark;
	}
	public Category() {
		super();
	}
	
	
}
