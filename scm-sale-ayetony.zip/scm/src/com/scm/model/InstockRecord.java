package com.scm.model;

/**
 *	入库记录表模型 
 */
public class InstockRecord {
	
	private int stockId;//序列号
	private String productCode;//产品编号
	private String orderCode;//相关单据号
	private int stockNum;//入库数量
	private int stockType;//入库类型
	private String stockTime;//入库时间
	private String createUser;//经手人
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public int getStockNum() {
		return stockNum;
	}
	public void setStockNum(int stockNum) {
		this.stockNum = stockNum;
	}
	public int getStockType() {
		return stockType;
	}
	public void setStockType(int stockType) {
		this.stockType = stockType;
	}
	public String getStockTime() {
		return stockTime;
	}
	public void setStockTime(String stockTime) {
		this.stockTime = stockTime;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public InstockRecord(int stockId, String productCode, String orderCode,
			int stockNum, int stockType, String stockTime, String createUser) {
		super();
		this.stockId = stockId;
		this.productCode = productCode;
		this.orderCode = orderCode;
		this.stockNum = stockNum;
		this.stockType = stockType;
		this.stockTime = stockTime;
		this.createUser = createUser;
	}
	public InstockRecord() {
		super();
	}
	
	
	
}
