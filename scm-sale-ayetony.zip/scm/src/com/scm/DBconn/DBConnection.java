package com.scm.DBconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Loading mysql driver");
		} catch (ClassNotFoundException e) {
			System.err.println("failed to load the driver");
		}
	}

	public static Connection getConn() {
		try {
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/scm", "root", "miao1990");
			System.out.println("connect to scm db.");
			return con;
		} catch (SQLException e) {
			System.err.println("failed to connected to scm db."
					+ e.getMessage());
		}
		return null;
	}

	public static void close(ResultSet rs, Statement stat, Connection conn) {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (stat != null) {
				stat.close();
				stat = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}

			System.out.println("close the connection.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		DBConnection.getConn();
	}
}
