function del(x){
	var cfirm = confirm("Continue to operate?");
	if (!cfirm){
		return false;
	} else {
		var rowIndex = x.parentNode.parentNode.rowIndex;
		var table = document.getElementById("myTable");
		var soId = table.rows[rowIndex].cells[0].innerText;
		// alert(soId);
		loadXHR(soId);
	}
}

//w3c拿来的XMLHTTPrEQUEST.
function loadXHR(soId){
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			if(xmlhttp.responseText==0){
				alert("删除失败咯");
			}
			//返回值
			if (xmlhttp.responseText != 0) {
				alert(decodeURI(xmlhttp.responseText));
				location.reload();
			}
		}
	};
	xmlhttp.open("GET", "/scm/AjaxDelServlet?soId=" + soId, true);
	xmlhttp.send();
}

//点击修改按钮跳转到修改的页面
function alter(x){

		var rowIndex = x.parentNode.parentNode.rowIndex;
		var table = document.getElementById("myTable");
		var soId = table.rows[rowIndex].cells[0].innerText;
		window.location="http://localhost:8080/scm/ModifySalesServlet?soId="+soId;
	
}


