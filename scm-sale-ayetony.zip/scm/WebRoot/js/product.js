var rowlength; // 每行多少个单元
var spxxTable;
var rowIndex;

function init() {

	rowlength = document.getElementById("spxxTable").rows[0].cells.length;
	spxxTable = document.getElementById("spxxTable");
}

// 逻辑控制
function choiceAnonymous() {
	var len = spxxTable.rows.length;
	var returnValue;
	var i;
	for (i = 1; i < len - 1; i++) {
		if (spxxTable.rows[i].cells[0].innerHTML == "\u221a") {
			returnValue = choice(i);
			setValue();
			hiddenDiv();
			return;
		}
	}
	alert("\u8bf7\u5148\u9009\u62e9\u5546\u54c1");

	function setValue() {

		var detailTable = document.getElementById("detailTable");
		var length = detailTable.rows.length;
		var spbm = document.getElementsByName("spbm");
		var spmc = document.getElementsByName("spmc");
		var spdw = document.getElementsByName("spdw");
		var spdj = document.getElementsByName("spdj");
		spbm[rowIndex].value = returnValue[0];
		spmc[rowIndex].value = returnValue[1];
		spdw[rowIndex].value = returnValue[2];
		spdj[rowIndex].value = returnValue[3];
		document.getElementsByName("spsl")[rowIndex].value = 0;

		// 修改自动计算
		document.getElementsByName("spsl")[rowIndex].onchange = function() {

			var productQty = parseInt(document.getElementsByName("spsl")[rowIndex].value);
			var productPrice = document.getElementsByName("spdj")[rowIndex].value;
			var productSum = document.getElementsByName("spzj")[rowIndex];
			productSum.value = to2Decimal(productQty * productPrice);

			var oTotal = document.getElementById("saleTotal");
			var tipFee = document.getElementById("tipFee").value;
			var items = document.getElementsByName("spzj");
			var sum = 0;
			for ( var index = 0; index < items.length; index++) {
				sum += parseFloat(items[index].value);
			}
			oTotal.value = to2Decimal(parseFloat(tipFee) + sum);

		};

	}
}

function selectItem(tr) {
	clearTable();
	// 不准重复选择相同的商品
	var productCode = tr.cells[1].innerHTML;
	var spbm = document.getElementsByName("spbm");
	for ( var i = 0; i < spbm.length; i++) {
		if (spbm[i].value == productCode) {
			alert("商品已经选择!");
			break;
		}
		if (i == spbm.length - 1) {
			tr.cells[0].innerHTML = "\u221a";
			var tds = tr.cells;
			var j;
			for (j = 0; j < tds.length; j += 1) {
				tds[j].style.backgroundColor = "#C1CDD8";

			}
		}

	}

}

function choice(index) {
	var row = document.getElementById("spxxTable").rows[index];
	var result = new Array(rowlength);
	var i;
	for (i = 1; i < rowlength; i++) {
		result[i - 1] = row.cells[i].innerHTML;
	}
	return result;
}
function choiceSpxx(rowIndex_) {
	showDiv();
	rowIndex = rowIndex_;
}

// 添加一行
function addItem() {

	var detailTable = document.getElementById("detailTable");
	var oRow = detailTable.insertRow(-1);// 在表格最后添加一行
	oRow.align = "center";
	oRow.className = "toolbar";
	oCell = oRow.insertCell(0);// 添加单元格
	oCell.innerHTML = oRow.rowIndex;
	oCell = oRow.insertCell(1);
	oCell.innerHTML = "<input type='text'  name='spbm' size='10' readonly> <span class='LL'><image src='images/selectDate.gif' onClick='choiceSpxx(\""
			+ (oRow.rowIndex - 1) + "\")'></span>";

	// oCell.class= ;
	oCell = oRow.insertCell(2);
	oCell.innerHTML = "<input type='text' name='spmc' size='15' readonly>";
	oCell = oRow.insertCell(3);
	oCell.innerHTML = "<input type='text' name='spsl' size='10' value='0'>";
	oCell = oRow.insertCell(4);
	oCell.innerHTML = "<input type='text' name='spdw' size='10' value='0' readonly>";
	oCell = oRow.insertCell(5);
	oCell.innerHTML = "<input type='text' name='spdj' size='10' value='0' readonly>";
	oCell = oRow.insertCell(6);
	oCell.innerHTML = "<input type='text' name='spzj' size='10' value='0' readonly>";
	oCell = oRow.insertCell(7);
	oCell.innerHTML = "<image src=\"images/delete.gif\" class=\"LL\" onclick=\"delItem("
			+ oRow.rowIndex + ")\"/>";
}
// 删除行,注意这里的行号全部要重新计算 刷新的
function delItem(index) {
	var detailTable = document.getElementById("detailTable");
	detailTable.deleteRow(index);
	var rowNum = detailTable.rows.length;
	var rowlength = detailTable.rows[0].cells.length;
	for ( var i = index; i < rowNum; i++) {
		detailTable.rows[i].cells[0].innerHTML = i;
		detailTable.rows[i].cells[rowlength - 1].innerHTML = "<image src=\"images/delete.gif\" class=\"LL\" onclick=\"delItem("
				+ i + ")\"/>";
	}

}
function hiddenDiv() {
	document.getElementById("productDiv").style.visibility = "hidden";
	clearTable();
}
function showDiv() {
	document.getElementById("productDiv").style.visibility = "visible";

}

function clearTable() {
	var trs = spxxTable.rows;
	for ( var i = 1; i < trs.length - 1; i += 1) {
		trs[i].cells[0].innerHTML = "";
		var tds = trs[i].cells;
		for ( var j = 0; j < tds.length; j += 1) {
			tds[j].style.backgroundColor = "#fff7e5";
		}
	}

}
