//获取当前的时间
function getFormatDate(oIpt) {
	var date = new Date();
	var seperator1 = "-";
	var seperator2 = ":";
	var month = date.getMonth() + 1;
	var strDate = date.getDate();
	if (month >= 1 && month <= 9) {
		month = "0" + month;
	}
	if (strDate >= 0 && strDate <= 9) {
		strDate = "0" + strDate;
	}
	var currentdate = date.getFullYear() + seperator1 + month + seperator1
			+ strDate + " " + date.getHours() + seperator2 + date.getMinutes()
			+ seperator2 + date.getSeconds();
	oIpt.value = currentdate;
}

// 需要等dom加载后才可以运行
window.onload = function() {

	var opt = document.getElementById("date");
	getFormatDate(opt);
	var oIp = document.getElementById("prePayFee");
	oIp.style.backgroundColor = "silver";
	oIp.readOnly = true;
	oIp.value = "不需填写";

};

// 给付款方式添加监听事件change
function changeSel(oSel) {
	var oIp = document.getElementById("prePayFee");
	// alert(oSel.selectedIndex);
	if (oSel.selectedIndex != 1) {
		oIp.style.backgroundColor = "silver";
		oIp.readOnly = true;
		oIp.value = "不需填写";

	} else {
		oIp.style.backgroundColor = "white";
		oIp.readOnly = false;
		oIp.value = "";
		oIp.placeholder = "请填写";

	}
}

// 保留两位小数,末尾会补充两个00
function to2Decimal(x) {
	var f = parseFloat(x);
	if (isNaN(f)) {
		return false;
	}
	var f = Math.round(x * 100) / 100;
	var s = f.toString();
	var rs = s.indexOf('.');
	if (rs < 0) {
		rs = s.length;
		s += '.';
	}

	while (s.length <= rs + 2) {
		s += '0';
	}
	return s;

}


// 只能输入正整数的正则表达函数
function isInteger(x) {

	var reg = /^[1-9]{1}[0-9]{0,5}$/;
	return reg.test(x);

}

// 提交之前的蹂躏
function send(save) {
	var date = document.getElementById("date");

	if (date.value == 0) {
		alert("请双击->创建时间");
		return;
	}
	var productCode = document.getElementsByName("spbm");
	if (productCode.length == 0) {
		alert("请增加明细");
		return;
	}
	
	
	var productQty = document.getElementsByName("spsl");

	for ( var i = 0; i < productQty.length; i++) {
		if (!isInteger(productQty[i].value)) {
			alert("明细单产品数量必须整数");
			return;
		}

	}

	for ( var i = 0; i < productCode.length; i++) {
		if(productCode[i].value == '') {
			alert("请选择商品编码");
			return;
		}

	}
	
		
    document.getElementById("mainForm").submit();
		
	
    


}


